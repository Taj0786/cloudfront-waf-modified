import json
import os
import boto3
from datetime import datetime
import base64
import zlib

sns = boto3.client('sns')

def handler(event, context):
    if 'awslogs' in event:
        compressed = base64.b64decode(event['awslogs']['data'])
        uncompressed = zlib.decompress(compressed, 16 + zlib.MAX_WBITS)
        payload = json.loads(uncompressed.decode('utf-8'))
        for log_event in payload['logEvents']:
            message = log_event['message']
            if "BLOCK" in message.upper():
                sns.publish(
                    TopicArn=os.environ['SNS_TOPIC_ARN'],
                    Message=f"WAF BLOCKED request:\n{message}",
                    Subject="WAF Block Alert - myapp-prod"
                )
        return {"status": "notification sent"}
    # Normal API request
    tags_env = os.environ.get('TAGS', '{}')
    tags = json.loads(tags_env) if tags_env else {}
    http_method = event.get('httpMethod', 'GET')
    path = event.get('path', '/')
    headers = event.get('headers', {})
    query_params = event.get('queryStringParameters', {})
    client_ip = headers.get('x-forwarded-for', 'unknown')
    user_agent = headers.get('user-agent', 'unknown')
    response_body = {
        "status": "success",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "request": {
            "method": http_method,
            "path": path,
            "client_ip": client_ip,
            "user_agent": user_agent
        },
        "architecture": "Client → CloudFront → AWS WAF → API Gateway → Lambda",
        "environment": os.environ.get('ENVIRONMENT', 'unknown'),
        "tags": tags,
        "waf_protected": True,
        "cloudfront_cdn": True
    }
    if query_params:
        response_body["request"]["query_parameters"] = query_params
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        },
        "body": json.dumps(response_body, indent=2)
    }